# ift3325_tp2
Implanter une version simplifiée du protocole HDLC
